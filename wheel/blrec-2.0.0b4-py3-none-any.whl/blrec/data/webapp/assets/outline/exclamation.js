(function() {
  __ant_icon_load({
      name: 'exclamation',
      theme: 'outline',
      icon: '<svg viewBox="64 64 896 896" focusable="false"><path d="M448 804a64 64 0 10128 0 64 64 0 10-128 0zm32-168h64c4.4 0 8-3.6 8-8V164c0-4.4-3.6-8-8-8h-64c-4.4 0-8 3.6-8 8v464c0 4.4 3.6 8 8 8z" /></svg>'
  });
})()