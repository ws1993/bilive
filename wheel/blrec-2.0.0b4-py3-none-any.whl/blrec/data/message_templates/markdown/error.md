异常信息：

```python
{{ event.data.detail }}
```
